let pTag = document.createElement('p')
pTag.innerText = 'Hello from main js'

let body = document.body

body.appendChild(pTag)