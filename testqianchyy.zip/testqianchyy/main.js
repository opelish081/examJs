var arr = ['a','b','c','d','e','f']
var arr2 = arr.shift()
console.log(arr);
console.log(arr2);